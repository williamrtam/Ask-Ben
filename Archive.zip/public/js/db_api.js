function getAllTags(connection, callback) {
    var query = 'select tag, post_ids from tags;';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get next post id');
            return callback(err, null);
        } else {
            return callback(null, rows);
        }
    }); 
}

function getNextPostID(connection, callback) {
    var query = 'select count(post_id) as count from posts;';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get next post id');
            return callback(err, null);
        } else {
            var nextPostID = rows[0].count + 1;
            return callback(null, nextPostID);
        }
    }); 
}

function getNextCommentID(connection, callback) {
    var query = 'select count(comment_id) as count from comments;';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get next comment id');
            return callback(err, null);
        } else {
            var nextCommentID = rows[0].count + 1;
            return callback(null, nextCommentID);
        }
    }); 
}

function getUsername(email, connection, callback) {
    var query = 'select username from users where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get username');
            return callback(err, null);
        } else {
            var username = rows[0].email;
            return callback(null, username);
        }
    }); 
}

function updateUpvotePostIDs (new_post_ids, email) {
    var query2 = 'update users set upvote_post_ids = ' + new_post_ids + ' where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
    if (err) {
        console.log(err);
    } else {
        console.log('updated upvote post ids');
        return true;
    }
    });             
}

function updateDownvotePostIDs (new_post_ids, email) {
    var query2 = 'update users set downvote_post_ids = ' + new_post_ids + ' where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
    if (err) {
        console.log(err);
    } else {
        console.log('updated downvote post ids');
        return true;
    }
    });             
}

function updatePostRating (post_id, change) {
    var query = 'select rating from posts where post_id = ' + post_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('did not upvote post');
            return false;
        } else {
            var newVal = rows[0].rating + change;
            var query2 = 'update posts set rating = ' + newVal + ' where post_id = ' + post_id + ';';
            console.log('upvoted post');
            return true;
        }
    });
}
    

function upVotePost(post_id, email, connection) {
    var index_skip = -1;
    var upvote_ids = "";
    var downvote_ids = "";
    var query = 'select upvote_post_ids from users where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('did not get upvote post ids ');
            return false;
        } else {
            upvote_ids = rows[0].upvote_post_ids;
            var post_ids = rows[0].upvote_post_ids.split(',');
            for (var i = 0; i < post_ids.length - 1; i++) {
                if (post_ids[i] == post_id) {  
                    index_skip = i;
                    break;
                }
            }
            if (index_skip != -1) {
                var new_post_ids = "";
                for (var i = 0; i < post_ids.length - 1; i++) {
                    if (i == index_skip) {
                        continue;
                    }
                    new_post_ids = concat(new_post_ids[i],',');
                }
                updateUpvotePostIDs(new_post_ids, email);
                updatePostRating(post_id, -1);
                return true;
            } else {
                var query2 = 'select downvote_post_ids from users where email = "' + email + '";';
                connection.query(query, function(err, rows, fields) {
                if (err) {
                    console.log(err);
                    console.log('did not get downvote post ids ');
                    return false;
                } else {
                    downvote_ids = rows[0].downvote_post_ids;
                    var post_ids2 = rows[0].downvote_post_ids.split(',');
                    index_skip = -1;
                    for (var i = 0; i < post_ids2.length - 1; i++) {
                        if (post_ids2[i] == post_id) {  
                            index_skip = i;
                            break;
                        }
                    }
                    if (index_skip != -1) {
                    var new_post_ids2 = "";
                    for (var i = 0; i < post_ids2.length - 1; i++) {
                        if (i == index_skip) {
                            continue;
                        }
                        new_post_ids2 = concat(new_post_ids2[i],',');
                    }
                    updateDownvotePostIDs(new_post_ids2, email);
                    upvote_ids = concat(upvote_ids, post_id + ',');
                    updateUpvotePostIDs(upvote_ids, email);
                    updatePostRating(post_id, 2);
                    return true;
                    } else {
                        upvote_ids = concat(upvote_ids, post_id + ',');
                        updateUpvotePostIDs(upvote_ids, email);
                        updatePostRating(post_id, 1);
                        return true;
                    }
                }
                });
            }  
        }
    });     
}

function downVotePost(post_id, email, connection) {
    var index_skip = -1;
    var upvote_ids = "";
    var downvote_ids = "";
    var query = 'select downvote_post_ids from users where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('did not get downvote post ids ');
            return false;
        } else {
            downvote_ids = rows[0].downvote_post_ids;
            var post_ids = rows[0].downvote_post_ids.split(',');
            for (var i = 0; i < post_ids.length - 1; i++) {
                if (post_ids[i] == post_id) {  
                    index_skip = i;
                    break;
                }
            }
            if (index_skip != -1) {
                var new_post_ids = "";
                for (var i = 0; i < post_ids.length - 1; i++) {
                    if (i == index_skip) {
                        continue;
                    }
                    new_post_ids = concat(new_post_ids[i],',');
                }
                updateDownvotePostIDs(new_post_ids, email);
                updatePostRating(post_id, 1);
                return true;
            } else {
                var query2 = 'select upvote_post_ids from users where email = "' + email + '";';
                connection.query(query, function(err, rows, fields) {
                if (err) {
                    console.log(err);
                    console.log('did not get upvote post ids ');
                    return false;
                } else {
                    upvote_ids = rows[0].upvote_post_ids;
                    var post_ids2 = rows[0].upvote_post_ids.split(',');
                    index_skip = -1;
                    for (var i = 0; i < post_ids2.length - 1; i++) {
                        if (post_ids2[i] == post_id) {  
                            index_skip = i;
                            break;
                        }
                    }
                    if (index_skip != -1) {
                    var new_post_ids2 = "";
                    for (var i = 0; i < post_ids2.length - 1; i++) {
                        if (i == index_skip) {
                            continue;
                        }
                        new_post_ids2 = concat(new_post_ids2[i],',');
                    }
                    updateUpvotePostIDs(new_post_ids2, email);
                    downvote_ids = concat(downvote_ids, post_id + ',');
                    updateDownvotePostIDs(downvote_ids, email);
                    updatePostRating(post_id, -2);
                    return true;
                    } else {
                        downvote_ids = concat(downvote_ids, post_id + ',');
                        updateDownvotePostIDs(downvote_ids, email);
                        updatePostRating(post_id, -1);
                        return true;
                    }
                }
                });
            }  
        }
    });     
}

function upVoteComment(comment_id, connection) {
    var query = 'select upvotes from comments where comment_id = ' + comment_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('did not upvote comment');
            return false;
        } else {
            var newVal = rows[0].upvotes + 1;
            var query2 = 'update comments set upvotes = ' + newVal + ' where comment_id = ' + comment_id + ';';
            console.log('upvoted comment');
        }
    });
}

function downVoteComment(comment_id, connection) {
    var query = 'select downvotes from comments where comment_id = ' + comment_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            consol.log('did not downvote comment');
            return false;
        } else {
            var newVal = rows[0].comments + 1;
            var query2 = 'update comments set downvotes = ' + newVal + ' where comment_id = ' + comment_id + ';';
            console.log('downvoted comment');
        }
    }); 
}

function getPostIDsFromTag(tag, connection) {
    var query = 'select post_ids from tags where tag = ' + tag + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('did not get post ids from tag');
            return null;
        } else {
            var post_ids = row[0].post_ids.split(',');
            console.log('got posts ids from tag');
            return post_ids;
        }
    });
}

function comment(comment_id, post_id, content, time, email, connection) {
    var query = 'insert into comments (comment_id, post_id, content, upvotes, downvotes, time, email)' + 
    'values (' + comment_id + ', ' + post_id + ', "' + content + '", 0, 0, ' + time + ', "' + email + '");';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('comment was not stored succesffully');
            return false;
        } else {
            console.log('comment was stored successfully');
            var query2 = 'update users set comment_ids = concat(comment_ids,"' + comment_id + ',");';
            connection.query(query2, function(err, rows, fields) {
                if (err) {
                    console.log(err);
                    console.log('comment id not updated');
                    return false;
                } else {
                    console.log('comment id updated');
                    return true;
                }
            });
        }
    });
}

function postQuestion(post_id, content, tags, header, time, email, anonymous, rating, connection) {
    var query = 'insert into posts (post_id, content, tags, header, time, email, anonymous, rating) ' + 
        'values (' + post_id + ', "' + content + '", "' + tags + '", "' + header + '", ' + 
        time + ', "' + email + '", ' + anonymous +', ' + rating + ');';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('post was not stored succesfully');
            return false;
        } else {
            // console.log('post was stored successfully');
            // console.log('tagstring: ' + tags);
            var query2 = 'update users set post_ids = concat(post_ids,"' + post_id + ',");';
            connection.query(query2, function(err, rows, fields) {
                if (err) {
                    console.log(err);
                    console.log('post id not updated');
                    return false;
                } else {
                    // console.log('post id updated');
                    console.log(rows);
                    return true;
                }
            });
            return true;
        }
    });

    return true;
}

function getPostTime(post_id, connection) {
    var query = 'select time from posts where post_id = ' + post_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get post time');
            return null;
        } else {
            console.log('got post time');
            return row[0].time;
        }
    }); 
}

function getCommentTime(comment_id, connection) {
    var query = 'select time from comments where comment_id = ' + comment_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get comment time');
            return null;
        } else {
            console.log('got comment time');
            return row[0].time;
        }
    }); 
}

// to get specific info do row[0].content where content is a column in the database. could be row[0].time etc
function getPostInfo(post_id, connection, callback) {
    var query = 'select * from posts where post_id = ' + post_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get post info');
            return callback(err, null);
        } else {
            console.log('got post info');
            return callback(null,rows[0]);
        }
    }); 
}

// to get specific info do row[0].upvotes where upvotes is a column in the database and 0 is the post_id
function getCommentInfo(comment_id, connection, callback) {
    var query = 'select * from comments where comment_id = ' + comment_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get comment info');
            return callback(err, null);
        } else {
            console.log('got comment info');
            return callback(err, rows[0]);
        }
    }); 
}

// to get specific info do row[0].post_id where 0 is the post_id
function getAllPostIDs(connection, callback) {
    var query = 'select post_id from posts;';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get all post IDs');
            return callback(err, null);
        } else {
            console.log('got all post IDs');
            return callback(null, rows);;
        }
    }); 
}

// to get specific info do row[0].post_id where 0 is the post_id
function getAllCommentIDs(post_id, connection, callback) {
    var query = 'select comment_id from comments where post_id = ' + post_id + ';';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not get all comment IDs');
            return callback(err, null);
        } else {
            console.log('got all comment IDs');
            return callback(null, rows);;
        }
    }); 
}


function updateUserInfo(email, value, field, connection) {
    var query = 'UPDATE users SET ' + field +'=' + '"' + value + '" ' + 'WHERE email =' + '"' + email + '";';
    connection.query(query, function(err, rows, fields) {
        if (err) {
            console.log(err);
            console.log('could not access user info');
            return false;
        } else {
            console.log('accessed user info');
            console.log(rows);
        }
    }); 
}

module.exports = {
    upVotePost, 
    downVotePost,
    upVoteComment,
    downVoteComment,
    getPostIDsFromTag,
    comment,
    postQuestion,
    getPostTime,
    getCommentTime,
    getPostInfo,
    getCommentInfo,
    getAllPostIDs,
    updateUserInfo,
    getNextPostID, 
    getNextCommentID,
    getUsername, 
    getAllTags,
    updateUpvotePostIDs, 
    updatePostRating,
    updateDownvotePostIDs,
    getAllCommentIDs
};



