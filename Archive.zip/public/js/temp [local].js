$( ".post-btn" ).click(function() {
  var newCard = $('<div class="card card-spacing" style="width: 40rem;" reputation="0" toggled="0">' + 
    '<div class="card-body card-head"> <a class="card-link card-col card-question" href="#">' + $('#input-question').val() +'</a>                <p class="card-text card-col">' + $('#input-expl').val() + '</p>                <hr>              </div>'+              
    '<div class="card-body card-content">                <p class="card-text card-col">' + str1 + '</p> <p class="card-text card-col">' + str2 + '</p>             </div>'+              
    '<div class="card-body vote">                <a style = "float: left" href="#" class="card-link link-size arrow arrow-up"> </a> <h4 id="rep-number" class="card-text card-col"></h4> <a href="#" class="card-link link-size arrow arrow-down"> </a>                <button style="float: right" type="button" class="btn btn-primary btn-sm answer" data-toggle="modal" data-target="#ans-modal"> Answer </button>              </div>'+       
    '<div class="card-body tags> <hr> <span class="card-text card-col" style="float: left"> tags </span> <button class="btn btn-primary btn-sm answer tag" style="float: left" type="button" data-toggle="modal" data-target="#"> #testing </button> </div>'+     
  '</div> ');
  $('.posts').append(newCard);
  $('.posts').children().last().each(function(i) {
    $(this).find("#rep-number").text($(this).attr('reputation'));
  });
  
  
  var tags = [];
  var text = $('#input-expl').val();
  text.toLowerCase();
  tags = text.match("/#[a-z]+)");
  if (tags !== null) {
    var i;
    for (i = 0; i < tags.length; i++) {
      $(newCard).append('<button class="btn btn-primary btn-sm answer tag" style="float: left; border-radius: 1px" type="button" data-toggle="modal" data-target="#tags-modal">' + tags[i] + '</button>');
    
    } 
  } else {
    $('.navbar').text("fufu");
  }
  
  
  
});

'<div class="card-body tags> <span class="card-text card-col" style="float: left"> tags </span> <button class="btn btn-primary btn-sm answer tag" style="float: left" type="button" data-toggle="modal" data-target="#"> #testing </button> </div>'


'<ul>div class="card card-spacing"> <div class="card-body card-head"> <a class="card-link card-col card-question" href="#"> Sample Profiles </a> <p class="card-text card-col">Some quick description of who has the top answer</p> <hr> </div> </div> </ul>'

'<div class="card card-spacing" style="width: 40rem;" reputation="0" toggled="0"> <div class="card-body card-head"> <a class="card-link card-col card-question" href="#"> Sample Question </a> <p class="card-text card-col">Some quick description of who has the top answer</p> <hr> </div> <div class="card-body card-content"> <p class="card-text card-col">Some quick example text from the top answer for given sample question. Some quick example text from the top answer for given sample question. Some quick example text from the top answer for given sample question. Some quick example text from the top answer for given sample question.</p> </div>  <div class="card-body vote" style="padding-bottom:0"> <a style = "float: left" href="#" class="card-link link-size arrow arrow-up"> </a> <h4 id="rep-number" class="card-text card-col"></h4> <a href="#" class="card-link link-size arrow arrow-down"> </a> <button style="float: right" type="button" class="btn btn-primary btn-sm answer" data-toggle="modal" data-target="#ans-modal"> Answer </button> <hr style="margin-bottom:0;padding-bottom:0" > </div> <div class="card-col tags"> <button class=" btn btn-sm tag" style="margin: 4px; padding:4px; background:black; border-radius: 10px" type="button" data-toggle="modal" data-target="#tags-modal">#faketag</button> </div> </div>'

//////////////////////////
var top =
'<div class='card-col tags' style>
  <button class=' btn btn-sm tag' style='margin: 4px; padding:4px; background:black; border-radius: 10px' type='button' data-toggle='modal' data-target='#tags-modal'>#faketag</button>
</div>
<div class='card-footer card-content' style='padding: 0px;'>
  <div class='card' style='width: 40rem; padding: 0px;'>
    <div class='card-body vote' style='padding-bottom:0'> <a style = 'float: left' href='#' class='card-link link-size arrow arrow-up'> </a> <h4 id='rep-number' class='card-text card-col'>
    </h4>
    <a href='#' class='card-link link-size arrow arrow-down'> </a>
    <button style='float: right' type='button' class='btn btn-primary btn-sm answer' data-toggle='modal' data-target='#ans-modal'> Answer </button> <hr style='margin-bottom:0;padding-bottom:0' >
</div>
<div class='card-footer card-content' style='padding: 0px;''>
  <div class='card' style='width: 40rem; padding: 0px;''>
    <div class='card-body' style='padding: 10px; padding-top: 20px; padding-bottom: 20px;'>
      <div class='question-input input-group mb-3' style='color: black'>
      <ul class='comments'> </ul>
      </div>
    </div>
  </div>
</div>
  </div>

</div>
</div>';
////////////////////////////////



// <div class="card-body tags>
//   <span class="card-text card-col" style="float: left"> tags </span>
//   <button class="btn btn-primary btn-sm answer tag" style="float: left; border-radius: 1px" type="button" data-toggle="modal" data-target="#tags-modal"> tags[i] </button>
//
// </div>