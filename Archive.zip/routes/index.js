var express = require('express');
var router = express.Router();
var path = require('path');
var fs = require('fs');
var session = require('express-session');

var passport = require('passport');
var passportSetup = require('../config/passport-setup');

var mysql = require('mysql');
var connection = mysql.createConnection({
  host     : 'cis350.c5rvqqjl9c91.us-east-1.rds.amazonaws.com',
  user     : 'cis350team46',
  password : 'cis350askben',
  database : 'cis350'
});

var db = require('../public/js/db_api');

var newPost = '';

// to login to database
// mysql -h cis350.c5rvqqjl9c91.us-east-1.rds.amazonaws.com -P 3306 -u cis350team46 -p
// cis350askben
// use cis350

// to see all the tables: show tables;
// to see the info in a specific table, users for example: select * from users;
// to see the description of the columns and their types of a specific table, posts for example: describe posts;

function upVotePostIndex(post_id) {
  db.upVotePost(post_id, session.email, connection);
  return db.getPostInfo(post_id, connection, function(err, post_info) {
    if (err) {
      console.log(err);
    } else if (post_info == null) {
      console.log('data is null');
    } else {
      return post_info.rating;
    }
  });
}

function downVotePostIndex(post_id) {
  db.downVotePost(post_id, session.email, connection);
  return db.getPostInfo(post_id, connection, function(err, post_info) {
    if (err) {
      console.log(err);
    } else if (post_info == null) {
      console.log('data is null');
    } else {
      return post_info.rating;
    }
  });
}

var NUM_MILLIS = 48 * 3600 * 1000;

function getMostRecentTags(num_tags) {
	db.getAllTags(connection, function(err, data) {
		if (err) {
			console.log(err);
		} else if (data == null) {
			console.log('data is null');
		} else {
			var curr_time = Date.now();
			var ret_2d_arr;
			for (var i = 0; i < data.length; i++) {
				var count = 0;
				var tag = data[i].tag;
				var post_id_arr = data[i].post_ids.split(",");
				for (var j = 0; j < post_id_arr.length-1; j++) {
					var post_time = db.getPostTime(post_id_arr[j], connection);
					if (curr_time - post_time <= NUM_MILLIS) {
						count++;
					}
				}
				ret_2d_arr.push([count, tag]);
			}

			ret_2d_arr.sort(function(a, b) {
			    if (a[0] === b[0]) {
			        return 0;
			    } else {
			        return (a[0] > b[0]) ? -1 : 1;
			    }
			});

			return ret_2d_arr.slice(0, 10);
		}
	});
}


function convertToArray(arrayOfObjects) {
	var array = [];
	for (i = 0; i < arrayOfObjects.length; i++) {
		array.push(arrayOfObjects[i].comment_id);
	}

	return array;
}

function loadPage(res, req, page) {
	if (page == 'home') {
		var email = req.session.email;
		console.log('home again');
		db.getAllPostIDs(connection, function(err, data) {
 			if (err) {
 				console.log(err);
 			} else if (data == null) {
 				console.log('data is null');
 			} else {
 				var post_list = [data];
 				// console.log('data is successfully extracted');
 				// console.log(data);
 				// console.log(post_list);

 				var posts_content = [];
 				var comment_arr = [];
 				var comments_info = new Array(data.length).fill([]);
 				console.log(data.length + '------------------------------' + comments_info.length);
 				for (i = 0; i < data.length; i++) {
 					console.log('Iter Outside: ' + i);
 					db.getPostInfo(data[i].post_id, connection, function(err, content) {
			 			if (err) {
			 				console.log(err);
			 			} else if (content == null) {
			 				console.log('content is null');
			 			} else {
			 				db.getAllCommentIDs(content.post_id, connection, function(err, comments) {
			 					//console.log('post content is successfully extracted');
			 					posts_content.push(content);
			 					comment_arr.push(comments);

			 					var comment_info_arr = [];
			 					// if (comments.length > 0) {
			 						// console.log('All comment info');
			 						// console.log(comments);
			 						// console.log(convertToArray(comments));
			 						//console.log(comments[0].comment_id);
			 					console.log('Post id ' + content.post_id);
			 					console.log(comments);
			 					if (comments.length == 0 && content.post_id == data.length) {
			 						comments_info[content.post_id-1] = comment_info_arr;
			 						res.render('home', {username: req.session.username, user: email, postIDs: post_list, posts: posts_content, comments: comment_arr, commentsInfo: comments_info});
			 					} else {
			 						for (j = comments.length-1; j >= 0; j--) {
				 						db.getCommentInfo(comments[j].comment_id, connection, function(err, info) {
				 							console.log('Info: ' + JSON.stringify(info));
				 							// console.log('Iter Inside: ' + j);
				 							if (err) {
				 								console.log(err);
				 							} else if (info == null) {
				 								// console.log('Returning null while getting comment info');
				 							} else {
				 								// console.log('Iter Inside Inside: ' + j);
				 								comment_info_arr.push(info.content);

				 								// Add set of comment info to the current post index
				 								// console.log(convertToArray(comments).indexOf(info.comment_id));
				 								// console.log(info.comment_id);
				 								if (convertToArray(comments).indexOf(info.comment_id)+1 == 1) {
				 									//console.log('End of comments');
				 									comments_info[info.post_id-1] = comment_info_arr;
				 									//console.log(comments_info);
				 								}

				 								console.log(info.post_id);
				 								console.log(convertToArray(comments).indexOf(info.comment_id));
								 				if (info.post_id == data.length && convertToArray(comments).indexOf(info.comment_id)+1 == 1) {
													res.render('home', {username: req.session.username, user: email, postIDs: post_list, posts: posts_content, comments: comment_arr, commentsInfo: comments_info});
													console.log(comments_info.length);
													console.log('DONE');
												}
				 							}
				 						});
			 						}
			 					}

			 						
			 				});


			 			}
			 		});			 		
 				}
 			}
 		});

	} else if (page == 'profile') {
		var data = {};
		var query = 'SELECT * from users where email = "' + req.session.email + '";';
    	connection.query(query, function(err, rows, fields) {
	        if (err) {
	            console.log(err);
	            console.log('could not get user info');
	        } else {
	            console.log('got user info');
	            console.log(rows[0]);
	            console.log(typeof rows[0].username);
	            res.render('profile', {email: rows[0].email, username: rows[0].username, major: rows[0].major, year: rows[0].year, city: rows[0].city, description: rows[0].description});
	        }
   		}); 		
	} else if (page == 'settings') {
		var data = {};
		var query = 'SELECT * from users where email = "' + req.session.email + '";';
    	connection.query(query, function(err, rows, fields) {
	        if (err) {
	            console.log(err);
	            console.log('could not get user info');
	        } else {
	            console.log('got user info');
	            console.log(rows[0]);
	            res.render('settings', {email: rows[0].email, password: rows[0].password});
	        }
   		}); 
	} else if (page == 'trending') {
		console.log("AT THE TRNDING");
		var data = {};
		var query = 'SELECT * from users where email = "' + req.session.email + '";';
    	connection.query(query, function(err, rows, fields) {
	        if (err) {
	            console.log(err);
	            console.log('could not get user info');
	        } else {
	            console.log('got user info');
	            console.log(rows[0]);
	            res.render('trending', {email: rows[0].email, password: rows[0].password});
	        }
	    });
	}
}

function checkSession(req, res, page) {
	if (req.session.email) {
		console.log('Still logged in');
		loadPage(res, req, page);
	} else {
		console.log('Logged Out');
		res.redirect('/');
	}
}

// GET routes

router.get('/', function(req, res, next) {
	res.render('welcome');
});

router.get('/signup',function(req,res) {
  res.render('signup', {userExists: false});
});

router.get('/login',function(req,res) {
	res.render('login', {userExists: false, wrongPassword: false});
});

router.get('/settings',function(req,res) {
	checkSession(req, res, 'settings');
});

router.get('/profile',function(req,res) {
	checkSession(req, res, 'profile');
});

router.get('/home',function(req,res) {
	checkSession(req, res, 'home');
});

router.get('/trending',function(req,res) {
	checkSession(req, res, 'trending');
});

router.get('/facebook', passport.authenticate('facebook'));

router.get('/auth/facebook', passport.authenticate('facebook'), function(req, res, next) {
	console.log(req.user);
	req.session.email = req.user.email;
	req.session.username = req.user.username;
	console.log('Got fb username: ' + req.session.username + '-------------------------------------------')
	var email = req.user.email.toLowerCase();
	var username = req.user.username;
	var query = 'SELECT email from users where email = "' + email + '";';
	connection.query(query, function(err, rows, fields) {
	    if (err) console.log(err);
	    else {
	    	if (rows[0] == null) {
	    		console.log("creating new account");
	    		req.session.email = email;
	    		var query2 = 'insert into users (email, password, username, major, year, city, description, post_ids, comment_ids)' + 
	    		'values ("' + email + '", null, "' + username + '", null, null, null, null, null, null);';
	    		console.log(query2);
	    		connection.query(query2, function(err, rows, fields) {
	   	 		if (err) console.log(err);
	    		else {
	    			res.redirect('/home');
	    		}
	    	})}
	    	else {
	    		console.log("email already in use");
	    		res.redirect('/home');
	    	}
	    }
    });
});

// POST requests

router.post('/signup', function(req, res) {
	console.log('Someone signed up');
	// Force lowercase on user email
	var email = req.body.email.toLowerCase();
	var username = req.body.username;
	var password = req.body.password;
	var query = 'SELECT email from users where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
	    if (err) console.log(err);
	    else {
	    	if (rows[0] == null) {
	    		console.log("creating new account");
	    		req.session.email = email;
	    		req.session.username = username;
	    		var query2 = 'insert into users (email, password, username, major, year, city, description, post_ids, comment_ids, upvote_post_ids, downvote_post_ids)' + 
	    		'values ("' + email + '", "' + password + '", "'+ username + '", null, null, null, null, null, null, null, null);';
	    		console.log(query2);
	    		connection.query(query2, function(err, rows, fields) {
	   	 		if (err) console.log(err);
	    		else {
	    			res.redirect('/home');
	    		}
	    	})}
	    	else {
	    		console.log("email already in use");
	    		res.render('signup', {userExists: true});
	    	}
	    }
    });
});

router.post('/login',function(req,res) {
	console.log('Someone logged in');
	var email = req.body.email.toLowerCase();
	var password = req.body.password;
	var query = 'SELECT email, password, username from users where email = "' + email + '";';
    connection.query(query, function(err, rows, fields) {
	    if (err) console.log(err);
	    else {
	    	if (rows[0] == null) {
	    		console.log("log in failed. no user with that email");
	    	    res.render('login', {userExists: true, wrongPassword: false});
	    	}
	    	else if (rows[0].email == email && rows[0].password == password) {
	    		console.log("log in successful");
	    		req.session.email = email;
	    		req.session.username = rows[0].username;
	    		console.log(req.session.username);
				res.redirect('/home');
	    	} else {
	    	    console.log("log in failed. wrong password");
	    	    res.render('login', {userExists: false, wrongPassword: true});
	    	}
	    }
    });
});

router.post('/logout',function(req,res) {
	req.session.destroy(function(err) {
		if (err) {
			res.negotiate(err);
		}
		console.log('Logging out');
		res.redirect('/');
	});
});

router.post('/postQuestion', function(req, res, next) {
	// Updates the database with the question and details about the post
	db.getNextPostID(connection, function(err, data) {
 		if (err) {
 			console.log(err);
 		} else if (data == null) {
 			console.log('data is null');
 		} else {
 			var post_id = data;
 			console.log("i hope this works: " + data);
 			var time = Date.now();

      // parses the posted question for tags, and submits them, comma-separated, as a string
      var tags = [];
      var re = new RegExp("#[a-z]+", "g");
      var details = req.body.question.toLowerCase();
      tags = details.match(re);
      // console.log('tags value: ' + tags.toString())
      if (tags !== null) {
        console.log("matches found\n" + tags);
        var uniques = [];
        for (var i = 0; i < tags.length; i++) {
          var temp = tags[i].slice(1);
          if (!uniques.includes(temp)) {
            uniques.push(temp);
          }
        }
        tags = uniques;
        console.log("#############\n\ttags displayed: " + uniques.length);
      } else {
        console.log("#############\n\tno matches found\n" + req.body.question);
      }

			db.postQuestion(post_id, req.body.details, tags.toString(), req.body.question, time, req.session.email, null, 0, connection);
 			setTimeout(function() {
 				res.redirect('/home');
 			}, 1000);
 			
 		}
 	});
});

router.post('/postAnswer', function(req, res, next) {
	// Updates the database with the question and details about the post
	//need to get postID
	db.getNextCommentID(connection, function(err, data) {
 		if (err) {
 			console.log(err);
 		} else if (data == null) {
 			console.log('data is null');
 		} else {
 			console.log('<-------------------------------------------------------------------------------------------->');
 			console.log(req.body);
 			var comment_id = data;
 			var time = Date.now();
 			post_id = req.body.post_id;
 			content = req.body.ans_content;
 			email = req.session.email;
 			db.comment(comment_id, post_id, content, time, email, connection);
 			res.redirect('/home');
 		}
 	});
});

router.post('/upload', function(req, res, next) {
	if (req.body.profilePicture) {
		console.log(req.body.picture);
	}
});

router.post('/updateInfo', function(req, res, next) {
	// Updates the database with the question and details about the post
	console.log("YAY");
	console.log(req.body);

	db.updateUserInfo(req.body.email, req.body.update, req.body.field, connection);
});



module.exports = router;
